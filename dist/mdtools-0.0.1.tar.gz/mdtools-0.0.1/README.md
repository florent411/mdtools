Extra MD Tools

Here some extra info.
